package pl.wr.math.object;

public class Point {

}
