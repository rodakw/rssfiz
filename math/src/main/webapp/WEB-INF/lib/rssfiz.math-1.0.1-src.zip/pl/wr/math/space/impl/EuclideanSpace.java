package pl.wr.math.space.impl;

import pl.wr.math.space.IMultidimensionalSpace;

public class EuclideanSpace implements IMultidimensionalSpace {

}
