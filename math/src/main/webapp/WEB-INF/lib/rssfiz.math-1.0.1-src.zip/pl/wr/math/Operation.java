package pl.wr.math;

/**
 * Mathematical operation
 * 
 * @version 1.0
 * @author wieslaw.rodak
 * 
 */
public enum Operation implements Component {

	add, sub, multi, div, pow, sqr;
}
