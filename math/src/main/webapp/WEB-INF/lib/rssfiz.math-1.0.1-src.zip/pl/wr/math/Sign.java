package pl.wr.math;

/**
 * Sign of a number.
 * 
 * @version 1.0
 * @author wieslaw.rodak
 * 
 */
public enum Sign implements Component {

	plus, minus;
}
