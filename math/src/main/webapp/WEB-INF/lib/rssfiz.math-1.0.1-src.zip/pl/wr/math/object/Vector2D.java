package pl.wr.math.object;

public final class Vector2D extends Vector {

    private Vector2D() {
        super(2);
    }

    public Vector2D(double x, double y) {
        this();
        rank[0] = x;
        rank[1] = y;
    }

    private Vector2D(double[] rank) {
        this();
        this.rank = rank;
    }

    public Vector2D add(Vector2D otherVector) {
        return new Vector2D(add(otherVector.rank));
    }
    
    public Vector2D subtract(Vector2D otherVector) {
        return new Vector2D(subtract(otherVector.rank));
    }

}
