package pl.wr.math;

import java.util.Collections;
import java.util.List;

/**
 * Mathematical formula
 * 
 * @version 1.0
 * @author wieslaw.rodak
 * 
 */
public class Formula {

	/**
	 * Field numerator.
	 */
	private List<Component> numerator = Collections.emptyList();
	/**
	 * Field denominator.
	 */
	private List<Component> denominator = Collections.emptyList();

	/**
	 * Method evaluate.
	 */
	public void evaluate() {

	}

	/**
	 * 
	 * @return the denominator
	 */
	public List<Component> getDenominator() {
		return denominator;
	}

	/**
	 * @param denominator
	 *            the denominator to set
	 */
	public void setDenominator(List<Component> denominator) {
		this.denominator = denominator;
	}

	/**
	 * 
	 * @return the numerator
	 */
	public List<Component> getNumerator() {
		return numerator;
	}

	/**
	 * @param numerator
	 *            the numerator to set
	 */
	public void setNumerator(List<Component> numerator) {
		this.numerator = numerator;
	}

}
