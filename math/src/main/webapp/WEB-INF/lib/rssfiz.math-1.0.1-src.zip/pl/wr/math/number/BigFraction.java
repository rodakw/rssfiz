package pl.wr.math.number;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;

import pl.wr.math.Component;
import pl.wr.math.utils.Util;

/**
 * Data type for ordinary fraction.
 * 
 * @version 1.0
 * @author wieslaw.rodak
 * 
 */
public final class BigFraction extends Number implements Component {

    /** A fraction representing "0". */
    public static final BigFraction ZERO = new BigFraction(0);

    /** A fraction representing "1". */
    public static final BigFraction ONE = new BigFraction(1);

    /** A fraction representing "-1". */
    public static final BigFraction MINUS_ONE = new BigFraction(-1);

    /** A fraction representing "1/2". */
    public static final BigFraction ONE_HALF = new BigFraction(1, 2);

    /** A fraction representing "-1/2". */
    public static final BigFraction MINUS_ONE_HALF = new BigFraction(-1, 2);

    /** A fraction representing "1/3". */
    public static final BigFraction ONE_THIRD = new BigFraction(1, 3);

    /** A fraction representing "-1/3". */
    public static final BigFraction MINUS_ONE_THIRD = new BigFraction(-1, 3);

    /** A fraction representing "2/3". */
    public static final BigFraction TWO_THIRDS = new BigFraction(2, 3);

    /** A fraction representing "-2/3". */
    public static final BigFraction MINUS_TWO_THIRDS = new BigFraction(-2, 3);

    /** A fraction representing "1/4". */
    public static final BigFraction ONE_QUARTER = new BigFraction(1, 4);

    /** A fraction representing "2/4". */
    public static final BigFraction TWO_QUARTERS = new BigFraction(2, 4);

    /** A fraction representing "3/4". */
    public static final BigFraction THREE_QUARTERS = new BigFraction(3, 4);

    /** A fraction representing "1/5". */
    public static final BigFraction ONE_FIFTH = new BigFraction(1, 5);

    /** A fraction representing "2/5". */
    public static final BigFraction TWO_FIFTHS = new BigFraction(2, 5);

    /** A fraction representing "3/5". */
    public static final BigFraction THREE_FIFTHS = new BigFraction(3, 5);

    /** A fraction representing "4/5". */
    public static final BigFraction FOUR_FIFTHS = new BigFraction(4, 5);

    /** A fraction representing "√2". */
    // public static final Fraction ROOT_2 = new Fraction(1.4142135623730951);
    public static final BigFraction ROOT_2 = new BigFraction(1767766952966369L, 1250000000000000L);
    // public static final BigFraction ROOT_2 = new BigFraction(new BigDecimal("176776695296636905").toBigInteger(), new
    // BigDecimal("125000000000000000").toBigInteger());

    /** A fraction representing "√3". */
    // public static final Fraction ROOT_3 = new Fraction(1.7320508075688772);
    public static final BigFraction ROOT_3 = new BigFraction(4330127018922193L, 2500000000000000L);

    /**
     * The uncertainty = 0
     */
    public static final int EXACTLY = 0;

    /**
     * The uncertainty = unknown
     */
    public static final int UNKNOWN = -1;

    /**
     * Field serialVersionUID. (value is -5481293843905644207)
     */
    private static final long serialVersionUID = -5481293843905644207L;

    /**
     * numerator of fraction
     */
    private BigInteger numerator;

    /**
     * denominator of fraction
     */
    private BigInteger denominator;

    /**
     * decimal power 10<sup>x</sup>
     */
    private int decimalPower;

    /**
     * standard uncertainty
     */
    private int uncertainty;

    /**
     * Fraction new instance
     */
    public BigFraction() {
        this(0L, 1L, 0);
    }

    /**
     * @param total
     *            - total number
     */
    public BigFraction(int total) {
        this((long) total, 1L, 0);
    }

    /**
     * @param fraction
     *            - fraction number
     */
    public BigFraction(Fraction fraction) {
        this(fraction.getNumerator(), fraction.getDenominator(), fraction.getDecimalPower());
    }

    /**
     * @param total
     *            - total number
     */
    public BigFraction(long total) {
        this(total, 1L, 0);
    }

    /**
     * @param numerator
     *            - numerator of fraction
     * @param denominator
     *            - denominator of fraction
     */
    public BigFraction(int numerator, int denominator) {
        this(numerator, denominator, 0);
    }

    /**
     * @param numerator
     *            - numerator of fraction
     * @param denominator
     *            - denominator of fraction
     * @param decimalPower
     *            - decimal power 10<sup>x</sup>
     */
    public BigFraction(int numerator, int denominator, int decimalPower) {
        this((long) numerator, (long) denominator, decimalPower);
    }

    /**
     * @param total
     *            - total number
     * @param numerator
     *            - numerator of fraction
     * @param denominator
     *            - denominator of fraction
     * @param decimalPower
     *            - decimal power 10<sup>x</sup>
     */
    public BigFraction(int total, int numerator, int denominator, int decimalPower) {
        this(total * denominator + numerator, denominator, decimalPower);
    }

    /**
     * @param numerator
     *            - numerator of fraction
     * @param denominator
     *            - denominator of fraction
     */
    public BigFraction(long numerator, long denominator) {
        this(numerator, denominator, 0);
    }

    /**
     * @param numerator
     *            - numerator of fraction
     * @param denominator
     *            - denominator of fraction
     * @param decimalPower
     *            - decimal power 10<sup>x</sup>
     */
    public BigFraction(long numerator, long denominator, int decimalPower) {
        this.numerator = BigInteger.valueOf(numerator);
        this.denominator = BigInteger.valueOf(denominator);
        this.decimalPower = decimalPower;
        uncertainty = EXACTLY;
    }

    /**
     * @param total
     *            - total number
     * @param numerator
     *            - numerator of fraction
     * @param denominator
     *            - denominator of fraction
     * @param decimalPower
     *            - decimal power 10<sup>x</sup>
     */
    public BigFraction(long total, long numerator, long denominator, int decimalPower) {
        this(total * denominator + numerator, denominator, decimalPower);
    }

    /**
     * @param decimalFraction
     *            - decimal fraction
     */
    public BigFraction(float decimalFraction) {
        this((double) decimalFraction, 0, EXACTLY);
    }

    /**
     * @param decimalFraction
     *            - decimal fraction
     */
    public BigFraction(double decimalFraction) {
        this(decimalFraction, 0, EXACTLY);
    }

    /**
     * @param decimalFraction
     *            - decimal fraction
     * @param decimalPower
     *            - decimal power 10<sup>x</sup>
     */
    public BigFraction(float decimalFraction, int decimalPower) {
        this((double) decimalFraction, decimalPower, EXACTLY);
    }

    /**
     * @param decimalFraction
     *            - decimal fraction
     * @param decimalPower
     *            - decimal power 10<sup>x</sup>
     */
    public BigFraction(double decimalFraction, int decimalPower) {
        this(decimalFraction, decimalPower, EXACTLY);
    }

    /**
     * @param decimalFraction
     *            - decimal fraction
     * @param decimalPower
     *            - decimal power 10<sup>x</sup>
     * @param uncertainty
     *            - standard uncertainty
     */
    public BigFraction(double decimalFraction, int decimalPower, int uncertainty) {
        final long[] c = Util.decimalToCommon(decimalFraction);
        numerator = BigInteger.valueOf(c[0]);
        denominator = BigInteger.valueOf(c[1]);
        this.decimalPower = decimalPower + (int) c[2];
        this.uncertainty = uncertainty;
    }

    public BigFraction(BigInteger numerator, BigInteger denominator) {
        this(numerator, denominator, 0);
    }

    public BigFraction(BigInteger numerator, BigInteger denominator, int decimalPower) {
        this.numerator = numerator;
        this.denominator = denominator;
        this.decimalPower = decimalPower;
        uncertainty = EXACTLY;
    }

    /**
     * 
     * @return - numerator of fraction
     */
    public BigInteger getNumerator() {
        return numerator;
    }

    /**
     * @param numerator
     *            - numerator of fraction
     */
    public void setNumerator(final BigInteger numerator) {
        this.numerator = numerator;
    }

    /**
     * 
     * @return - denominator of fraction
     */
    public BigInteger getDenominator() {
        return denominator;
    }

    /**
     * @param denominator
     *            - denominator of fraction
     */
    public void setDenominator(final BigInteger denominator) {
        if (0 == denominator.intValue())
            throw new ArithmeticException("denominator can not be zero");
        this.denominator = denominator;
    }

    /**
     * 
     * @return - decimal power 10<sup>x</sup>
     */
    public int getDecimalPower() {
        return decimalPower;
    }

    /**
     * @param decimalPower
     *            - decimal power 10<sup>x</sup>
     */
    public void setDecimalPower(final int decimalPower) {
        this.decimalPower = decimalPower;
    }

    /**
     * @return standard uncertainty
     */
    public int getUncertainty() {
        return uncertainty;
    }

    /**
     * @param uncertainty
     *            - standard uncertainty
     */
    public void setUncertainty(final int uncertainty) {
        this.uncertainty = uncertainty;
    }

    /**
     * Add two Fraction numbers
     * 
     * @param a
     *            - Fraction a
     * @param b
     *            - Fraction b
     * 
     * @return new Fraction c
     */
    public static BigFraction add(final BigFraction a, final BigFraction b) {

        final BigFraction a1 = BigFraction.clone(a);
        final BigFraction b1 = BigFraction.clone(b);
        final BigFraction c = new BigFraction();

        setCommonDecimalPower(a1, b1);

        c.setDecimalPower(a1.getDecimalPower());

        if (a1.getDenominator() == b1.getDenominator()) {
            c.setNumerator(a1.getNumerator().add(b1.getNumerator()));
            c.setDenominator(a1.getDenominator());
        } else {
            final BigInteger commonDenominator = Util.gcf(a1.getDenominator(), b1.getDenominator());
            final BigInteger aMultiplier = commonDenominator.divide(a1.getDenominator());
            final BigInteger bMultiplier = commonDenominator.divide(b1.getDenominator());
            c.setNumerator((a1.getNumerator().multiply(aMultiplier)).add(b1.getNumerator().multiply(bMultiplier)));
            c.setDenominator(commonDenominator);
        }

        // reduce the length numerator and denominator
        reduce(c);

        return c;
    }

    /**
     * Subtract two Fraction numbers
     * 
     * @param a
     *            - Fraction a
     * @param b
     *            - Fraction b
     * 
     * @return new Fraction c
     */
    public static BigFraction subtract(final BigFraction a, final BigFraction b) {

        final BigFraction a1 = BigFraction.clone(a);
        final BigFraction b1 = BigFraction.clone(b);
        final BigFraction c = new BigFraction();

        setCommonDecimalPower(a1, b1);

        c.setDecimalPower(a1.getDecimalPower());

        if (a1.getDenominator() == b1.getDenominator()) {
            c.setNumerator(a1.getNumerator().subtract(b1.getNumerator()));
            c.setDenominator(a1.getDenominator());
        } else {
            final BigInteger commonDenominator = Util.gcf(a1.getDenominator(), b1.getDenominator());
            final BigInteger aMultiplier = commonDenominator.divide(a1.getDenominator());
            final BigInteger bMultiplier = commonDenominator.divide(b1.getDenominator());
            c.setNumerator((a1.getNumerator().multiply(aMultiplier)).subtract(b1.getNumerator().multiply(bMultiplier)));
            c.setDenominator(commonDenominator);
        }

        // reduce the length numerator and denominator
        reduce(c);

        return c;
    }

    /**
     * @param a
     * @param b
     */
    private static void setCommonDecimalPower(BigFraction a, BigFraction b) {
        if (a.getDecimalPower() != b.getDecimalPower()) {
            if (a.getDecimalPower() > b.getDecimalPower()) {
                a.setNumerator((a.getNumerator().multiply(BigDecimal.valueOf(powerValue(a.getDecimalPower() - b.getDecimalPower())).toBigInteger())));
                a.setDecimalPower(b.getDecimalPower());
            } else {
                b.setNumerator((b.getNumerator().multiply(BigDecimal.valueOf(powerValue(b.getDecimalPower() - a.getDecimalPower())).toBigInteger())));
                b.setDecimalPower(a.getDecimalPower());
            }
        }
    }

    /**
     * Multiply two Fraction numbers
     * 
     * @param a
     *            - Fraction a
     * @param b
     *            - Fraction b
     * 
     * @return new Fraction c
     */
    public static BigFraction multiply(final BigFraction a, final BigFraction b) {

        final BigFraction c = new BigFraction();
        c.setDecimalPower(a.getDecimalPower() + b.getDecimalPower());

        final BigInteger numerator = a.getNumerator().multiply(b.getNumerator());
        final BigInteger denominator = a.getDenominator().multiply(b.getDenominator());

        c.setNumerator(numerator);
        c.setDenominator(denominator);

        // reduce the length numerator and denominator
        reduce(c);

        return c;
    }

    /**
     * Divide two Fraction numbers
     * 
     * @param a
     *            - Fraction a
     * @param b
     *            - Fraction b
     * 
     * @return new Fraction c
     */
    public static BigFraction divide(final BigFraction a, final BigFraction b) {

        final BigFraction c = new BigFraction();
        c.setDecimalPower(a.getDecimalPower() - b.getDecimalPower());

        final BigInteger numerator = a.getNumerator().multiply(b.getDenominator());
        final BigInteger denominator = a.getDenominator().multiply(b.getNumerator());

        c.setNumerator(numerator);
        c.setDenominator(denominator);

        // reduce the length numerator and denominator
        reduce(c);

        return c;
    }

    /**
     * Method intValue.
     * 
     * @return int
     */
    @Override
    public int intValue() {
        return bigDecimalValue().intValue();
    }

    /**
     * Method longValue.
     * 
     * @return long
     */
    @Override
    public long longValue() {
        return bigDecimalValue().longValue();
    }

    /**
     * Method floatValue.
     * 
     * @return float
     */
    @Override
    public float floatValue() {
        return bigDecimalValue().floatValue();
    }

    /**
     * Method doubleValue.
     * 
     * @return double
     */
    @Override
    public double doubleValue() {
        return bigDecimalValue().doubleValue();
    }

    /**
     * @return BigDecimal
     */
    public BigDecimal bigDecimalValue() {

        BigDecimal num = new BigDecimal(numerator).multiply(new BigDecimal(powerValue()));
        BigDecimal den = new BigDecimal(denominator);
        BigDecimal ret;
        try {
            ret = num.divide(den);
        } catch (ArithmeticException e) {
            ret = num.divide(den, MathContext.DECIMAL128);
        }

        return ret;
    }

    /**
     * Check if number is zero (numerator = 0)
     * 
     * 
     * @return true/false
     */
    public boolean isZero() {
        return (0 == numerator.longValue()) ? true : false;
    }

    /**
     * Method powerValue.
     * 
     * @return double
     */
    private double powerValue() {
        return Math.pow(10, decimalPower);
    }

    /**
     * Method powerValue.
     * 
     * @param pow
     *            int
     * @return double
     */
    private static double powerValue(final int pow) {
        return Math.pow(10, pow);
    }

    /**
     * Method toString.
     * 
     * @return String
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder(32);
        builder.append("BigFraction [numerator=");
        builder.append(numerator);
        builder.append(", denominator=");
        builder.append(denominator);
        builder.append(", decimalPower=");
        builder.append(decimalPower);
        builder.append(", uncertainty=");
        builder.append(uncertainty);
        builder.append(']');
        return builder.toString();
    }

    /**
     * @param oryginal
     *            - oryginal fraction
     * @return copy of oryginal
     */
    public static BigFraction clone(final BigFraction oryginal) {

        final BigFraction copy = new BigFraction(oryginal.getNumerator(), oryginal.getDenominator(), oryginal.getDecimalPower());
        copy.setUncertainty(oryginal.getUncertainty());

        return copy;
    }

    /**
     * Reduce numerator and denominator by greatest common divisor.
     * 
     * @param oryginal
     *            - Fraction number
     */
    public static void reduce(final BigFraction oryginal) {

        // final long divisor = Util.gcd(oryginal.getNumerator(), oryginal.getDenominator());
        final BigInteger divisor = oryginal.getNumerator().gcd(oryginal.getDenominator());

        if (divisor.intValue() > 1) {
            oryginal.setNumerator(oryginal.getNumerator().divide(divisor));
            oryginal.setDenominator(oryginal.getDenominator().divide(divisor));
        }
    }

    /**
     * @return
     */
    public long round() {
        return Math.round(doubleValue());
    }

    /**
     * Return the additive inverse of this fraction.
     * 
     * @return the negation of this fraction.
     */
    public BigFraction negate() {
        return new BigFraction(numerator.negate(), denominator);
    }

    /**
     * Return the multiplicative inverse of this fraction.
     * 
     * @return the reciprocal fraction
     */
    public BigFraction reciprocal() {
        return new BigFraction(denominator, numerator);
    }
}
