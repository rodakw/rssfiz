package pl.wr.math.space.impl;

import pl.wr.math.space.IMultidimensionalSpace;

/**
 * @version 1.0
 * @author wieslaw.rodak
 *
 */
public class PolarSpace implements IMultidimensionalSpace {

}
