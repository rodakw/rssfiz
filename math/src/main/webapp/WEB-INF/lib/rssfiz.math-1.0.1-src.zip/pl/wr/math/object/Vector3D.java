package pl.wr.math.object;

public class Vector3D extends Vector {

    private Vector3D() {
        super(3);
    }

    public Vector3D(double x, double y, double z) {
        this();
        rank[0] = x;
        rank[1] = y;
        rank[2] = z;
    }

    private Vector3D(double[] rank) {
        this();
        this.rank = rank;
    }

    public Vector3D add(Vector3D otherVector) {
        return new Vector3D(add(otherVector.rank));
    }
    
    public Vector3D subtract(Vector3D otherVector) {
        return new Vector3D(subtract(otherVector.rank));
    }

}
