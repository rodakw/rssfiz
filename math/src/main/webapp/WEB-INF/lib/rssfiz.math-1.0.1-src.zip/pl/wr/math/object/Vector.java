package pl.wr.math.object;

public abstract class Vector {

    protected final int dimension;
    protected double[] rank;

    public Vector(int dimension) {
        this.dimension = dimension;
        this.rank = new double[dimension];
    }

    public double[] add(double[] otherRank) {
        double[] result = new double[dimension];
        for (int i = 0; i < dimension; i++) {
            result[i] = rank[i] + otherRank[i];
        }
        return result;
    }
    
    public double[] subtract(double[] otherRank) {
        double[] result = new double[dimension];
        for (int i = 0; i < dimension; i++) {
            result[i] = rank[i] - otherRank[i];
        }
        return result;
    }

}
