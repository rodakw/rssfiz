package pl.wr.math.object;

public interface CoordinateSystem {

}
