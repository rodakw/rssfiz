package pl.wr.math;

/**
 * The mathematical formula component
 * 
 * @version 1.0
 * @author wieslaw.rodak
 *
 */
public interface Component {

}
