package pl.wr.math.object;

public class Tensor {

    private double scalar;
    private Vector3D vector;

    public Tensor(double scalar, Vector3D vector) {
        this.scalar = scalar;
        this.vector = vector;
    }

    public Tensor(double scalar, double x, double y, double z) {
        this.scalar = scalar;
        this.vector = new Vector3D(x, y, z);
    }

    public Tensor add(Tensor otherTensor) {
        double scalar = this.scalar + otherTensor.scalar;
        Vector3D vector = this.vector.add(otherTensor.vector);
        return new Tensor(scalar, vector);
    }

    public Tensor subtract(Tensor otherTensor) {
        double scalar = this.scalar - otherTensor.scalar;
        Vector3D vector = this.vector.subtract(otherTensor.vector);
        return new Tensor(scalar, vector);
    }

}
