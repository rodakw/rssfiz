package pl.wr.math.space;

/**
 * Multidimensional space.
 *
 * @version 1.0
 * @author wieslaw.rodak
 * 
 */
public interface IMultidimensionalSpace {

}
